const initialState =
{
    status: 'unlock',
    message: 'Welcome',
    password: [],
    input: []
};

const clickbutton = (state=initialState, action) =>{
    switch(action.type){
        case 'CLICK_NUMBER':
            if(state.input.length <4){
                if(state.status === 'lock'){
                    const newState = Object.assign({}, state, {message: state.input.concat(action.number).join(''), input: state.input.concat(action.number)})
                    
                    if(JSON.stringify(newState.input) === JSON.stringify(state.password)){
                        return Object.assign({}, newState, {input:[], message:'Welcome', status:'unlock', password:[]})
                    }
                    else{
                        return newState
                    }
                }
                else{
                    return Object.assign({}, state, {input: state.input.concat(action.number), password: state.password.concat(action.number), message: ['4 Digits Required', 'Welcome'].includes(state.message) ? action.number : state.message + action.number})
                }
            }

            return state
        case 'CLICK_ENTER':            
            if(state.status === 'lock'){
                return Object.assign({}, state, {message: 'INVALID', input: []})
            }
            else{
                if(state.password.length <4){
                    return Object.assign({}, state, {message:'4 Digits Required'})    
                }

                return Object.assign({}, state, {status: 'lock', input:[], message:''})
            }
        case 'CLICK_CLEAR':            
            if(state.status === 'lock'){
                return Object.assign({}, state, {input:[], message:''})
            }
            else{
                return Object.assign({}, state, {input:[], message:'', password:[]})
            }
        default:
            return state
    }
}

export default clickbutton