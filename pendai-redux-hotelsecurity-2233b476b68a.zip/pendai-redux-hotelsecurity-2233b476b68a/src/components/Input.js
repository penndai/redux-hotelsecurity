import React from 'react'
import InputRow from './InputRow';

const Inputer = (props)=>{    
    let rowdiv = props.values.map((value, index) =>{
        if (index % props.customnumber === 0){  
            let end = index + props.customnumber > props.values ? -1 : index + props.customnumber
            let buttonValues = props.values.slice(index, end)
            return(
                <div key={index} className="board-row">
                    <InputRow key={index} values={buttonValues}></InputRow>
                </div>
            )                      
        }

        return null;
    })

    return (
        <div>
            {rowdiv}
        </div>
    )
}

export default Inputer