import React from 'react'
import PropTypes from 'prop-types'

const DisplayLight = ({status, message}) => (
    <div>
        <div>
            <input type="text" className='input-element' value={message} readOnly></input>
        </div>
        <span className={status}></span>
    </div>
)

DisplayLight.propTypes = {
    status: PropTypes.string.isRequired,
    message: PropTypes.string.isRequired
}

export default DisplayLight