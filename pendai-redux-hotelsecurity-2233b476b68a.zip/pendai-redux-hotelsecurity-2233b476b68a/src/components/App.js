import React from 'react'
import DisplayLightContainer from '../containers/DisplayLightContainer'
import logo from '../logo.svg';
import Inputer from './Input'

const App = () =>(
    <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Hotel Security - React Redux</h1>
        </header>
        <p className="App-intro">         
        </p>
    
        <div className='container'>
            <div className='left'>
                <Inputer values={['1', '2', '3', '4', '5', '6', '7', '8', '9', 'CLR','0', '\u21E8']} customnumber={3}/>
            </div>
            <div className='right'>
                <DisplayLightContainer />        
            </div>
        </div>
    </div>
)

export default App