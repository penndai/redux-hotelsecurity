import React from 'react'
import PropTypes from 'prop-types'

class Button extends React.Component {   
    render(){
        return (
            <button type='button' className='square' onClick={(e) => this.props.onClick(e.target.innerHTML)}>
                {this.props.text}
            </button>
        )
    }
}

Button.propTypes={
    onClick: PropTypes.func.isRequired
}

export default Button