import React from 'react'
import NumberButtonContainer from '../containers/NumberButtonContainer'
import ClearButtonContainer from '../containers/ClearButtonContainer'
import EnterButtonContainer from '../containers/EnterButtonContainer'

const InputRow = (props) => {
    return props.values.map(value =>{
        let buttonelement
        if(!isNaN(value)){
            buttonelement=<NumberButtonContainer key={value} value={value}></NumberButtonContainer>
        }
        else if(value === 'CLR'){
            buttonelement=<ClearButtonContainer key={value} value={value}></ClearButtonContainer>
        }
        else{
            buttonelement=<EnterButtonContainer key={value} value={value}></EnterButtonContainer>
        }

        return buttonelement;
    })
}

export default InputRow