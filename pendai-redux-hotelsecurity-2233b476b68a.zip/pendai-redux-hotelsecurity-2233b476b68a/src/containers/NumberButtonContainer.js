import React from 'react'
import ReactDOM from 'react-dom'
import {connect} from 'react-redux'
import {clickNumber} from '../actions'
import Button from '../components/Button'

const mapStateToProps = (state, ownProps) => ({
    text: ownProps.value
})

const mapDispatchToProps = dispatch => ({
    onClick: number => dispatch(clickNumber(number))    
})

const ButtonWrapper = connect(
    mapStateToProps,
    mapDispatchToProps,
    null,
    {withRef:true}
  )(Button)

class ButtonContainer extends React.Component{   
    componentDidMount(){
        if (this.button) {
            let button_element = ReactDOM.findDOMNode(this.button)
            button_element.innerHTML = this.props.value    
        }
    }

    render(){
        return(
            <ButtonWrapper 
                ref={connectedComponent => this.button = connectedComponent.getWrappedInstance()}>
            </ButtonWrapper>
        )
    }
}

export default ButtonContainer
