import {connect} from 'react-redux'
import {clickClear} from '../actions'
import Button from '../components/Button'

const mapStateToProps = (state, ownProps) =>({
    text: ownProps.value
})

const mapDispatchToProps = dispatch => ({
    onClick: () => dispatch(clickClear())
})

export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(Button)