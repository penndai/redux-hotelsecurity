import {connect} from 'react-redux'
import {clickEnter} from '../actions'
import Button from '../components/Button'

const mapStateToProps = (state, ownProps) =>({
    text: ownProps.value
})

const mapDispatchToProps = dispatch => ({
    onClick: () => dispatch(clickEnter())
})

export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(Button)