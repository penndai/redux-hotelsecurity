import {connect} from 'react-redux'
import DisplayLight from '../components/DisplayLight'

const mapStateToProps = (state) => ({
    status: state.status,
    message: state.message
})

export default connect(mapStateToProps, null)(DisplayLight)