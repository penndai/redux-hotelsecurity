export const clickNumber = (number) =>({
    type: 'CLICK_NUMBER',
    number
})

export const clickEnter = ()=>({
    type: 'CLICK_ENTER'
})

export const clickClear = ()=>({
    type: 'CLICK_CLEAR'
})